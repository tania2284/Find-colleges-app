package com.example.myapp_assignment;

public class College {

    String Collegename;

    public College(String collegename) {
      this.Collegename = collegename;
       Collegename = collegename;
    }

    public College() {


    }
}
