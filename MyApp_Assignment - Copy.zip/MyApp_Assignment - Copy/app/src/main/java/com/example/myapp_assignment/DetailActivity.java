package com.example.myapp_assignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONException;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity implements NetworkinServices.NetworkingListener {
   // NetworkinServices networkinServices = new NetworkinServices();
  TextView collegename;
    ArrayList <College> collegelist1 = new ArrayList<>(0);
    NetworkinServices networkinServices = new NetworkinServices();
    JsonSevice jsonSevice = new JsonSevice();
    String col;
    //College college ;
   // RecyclerView recyclerView;
    //Recycleradapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        String countryName = getIntent().getStringExtra("SelectedCountry");
       // networkinServices.fetchinformation(countryName);
        networkinServices.listener = this;
        networkinServices.fetchCollegeData(countryName);
       // recyclerView = findViewById(R.id.countryrecycler);
       // recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //adapter = new Recycleradapter(this, collegelist);
      collegename = findViewById(R.id.collegename);

    }

    @Override
    public void APINetworkListner(String jsonString)  {


        College college = null;
        try {

            college = jsonSevice.parseCollegeAPIJson(jsonString);
          // collegename.setText(college.Collegename);
            col = college.Collegename;
            collegename.setText(col);
System.out.println(college.Collegename+"###############################");
        } catch (JSONException e) {
            e.printStackTrace();
        }



}
}
