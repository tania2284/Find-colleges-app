package com.example.myapp_assignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NetworkinServices.NetworkingListener, Recycleradapter.countryClickListner {
     JsonSevice jsonSevice = new JsonSevice();
     NetworkinServices networkinServices = new NetworkinServices();
     RecyclerView recyclerView;
     Recycleradapter adapter;
     ArrayList <Country> countrylist1 = new ArrayList<>(0);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        networkinServices.listener = this;

        recyclerView = findViewById(R.id.countryrecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new Recycleradapter(this, countrylist1);
        recyclerView.setAdapter(adapter);
        networkinServices.fetchinformation();


        }

    public void Intent  (Country selectedCountry) {

        Intent intent = new Intent(this,DetailActivity.class);
        intent.putExtra("SelectedCountry",selectedCountry.getCountryName());
        startActivity(intent);
    }


    @Override
    public void APINetworkListner(String jsonString) {
        countrylist1 = jsonSevice.parseCountriesAPIJson(jsonString);
      System.out.println("countrysizexxx"+ countrylist1.size());
        adapter.countryList = countrylist1;
        adapter.notifyDataSetChanged();

    }

    @Override
    public void countryClicked(Country selectedCountry) {
        Intent(selectedCountry);

    }
}