package com.example.myapp_assignment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonSevice {
//    QuestionModel question ;
//ArrayList<Country> allCountriesFromAPI = new ArrayList<>(0);
//    public QuestionModel parseWeatherAPIData(String jsonWeatherString){
//
//        try {
//            JSONObject jsonObject = new JSONObject(jsonWeatherString);// root
//            JSONArray weatherArray = jsonObject.getJSONArray("results");
//            JSONObject weatherObject = weatherArray.getJSONObject(0);
//            String des = weatherObject.getString("question");
//            question = new QuestionModel(des);
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return  question;
//    }
//
//}

    public ArrayList<Country> parseCountriesAPIJson(String jsonCountries) {
        ArrayList<Country> allCountriesFromAPI = new ArrayList<>(0);
        try {
            JSONArray jsonArray = new JSONArray(jsonCountries);//
            for (int i = 0; i < jsonArray.length(); i++) { // Iterate through the whole array
                JSONObject jsonObject = jsonArray.getJSONObject(i);//From inside array I need to get each object
                String countryName = jsonObject.getString("name");//From each object,extract the string using key
                allCountriesFromAPI.add(new Country(countryName)); //Add to the ArrayList
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return allCountriesFromAPI;
    }
//    ArrayList<College> allCollegeFromAPI;
//    public ArrayList<College> parseCollegeAPIJson(String jsonCollege){
//         College college = new College();
//
//        ArrayList<College> allCollegeFromAPI = new ArrayList<>(0);
//        try {//
//            JSONArray jsonArray = new JSONArray(jsonCollege);
//            for (int i = 0 ; i< jsonArray.length(); i++){
//                JSONObject jsonObject = jsonArray.getJSONObject(i);
//
//                String name = jsonObject.getString("name");
//          college = new College(name);
//                allCollegeFromAPI.add(college);//(new College(jsonArray.getString(i)));
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return allCollegeFromAPI;
//    }


    // ArrayList<College> allCollegeFromAPI;
    public College parseCollegeAPIJson(String jsonCollege) throws JSONException {
        College college = new College();// = new College();

        // ArrayList<College> allCollegeFromAPI = new ArrayList<>(0);
        JSONArray jsonArray = new JSONArray(jsonCollege);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);

            String name = jsonObject.getString("name");
            college = new College(name);}
            return college;
        }


    }
//    public  FruitData  parseFruitsSecondAPIJson(String jsonFruitInfoString) throws JSONException {
//        FruitData fruitData;
//        JSONObject jsonObject = new JSONObject(jsonFruitInfoString);
//        JSONArray fruitsInfoArray = jsonObject.getJSONArray("results");
//        JSONObject fruitObject = fruitsInfoArray.getJSONObject(0);
//        String imageString = fruitObject.getString("imageurl");
//        String desString   = fruitObject.getString("description");
//
//
////        fruitData = new FruitData(desString,imageString,usesString,healthString);
//        fruitData = new FruitData(desString,imageString,usesString,healthString,othname,propagation,soil,climate);
//        return fruitData;
//    }

